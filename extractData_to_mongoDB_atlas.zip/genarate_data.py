import requests
from pymongo import MongoClient

# MongoDB Atlas connection string
MONGO_URI = "mongodb+srv://blessingsmlundira:vjOUpGcniJ1QuRMo@cluster0.71vdfjx.mongodb.net/"
# MongoDB database name
DB_NAME = "hospital_facilities"
# MongoDB collection name
COLLECTION_NAME = "facilities"

# Connect to MongoDB Atlas
client = MongoClient(MONGO_URI)
db = client[DB_NAME]
collection = db[COLLECTION_NAME]

# API URL
API_URL = "https://zipatala.health.gov.mw/api/facilities"

def fetch_data_from_api():
    try:
        # Fetch data from the API
        response = requests.get(API_URL)
        data = response.json()
        return data
    except Exception as e:
        print("Error fetching data from the API:", e)
        return []

def insert_data_into_mongodb(data):
    try:
        # Insert data into MongoDB collection
        collection.insert_many(data)
        print("Data inserted into MongoDB successfully.")
    except Exception as e:
        print("Error inserting data into MongoDB:", e)

def main():
    # Fetch data from the API
    data = fetch_data_from_api()

    # Insert data into MongoDB
    if data:
        insert_data_into_mongodb(data)

if __name__ == "__main__":
    main()
