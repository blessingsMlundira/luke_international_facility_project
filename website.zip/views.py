from flask import Blueprint, render_template, request, flash, jsonify, request
from flask_login import login_required, current_user
from .models import Note
from . import db
import json

from pymongo import MongoClient
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import io
import base64

import requests  # Add this line to import the requests module
import random
import string

# Blueprint for views
views = Blueprint('views', __name__)

# Route for the home page
@views.route('/', methods=['GET', 'POST'])
@login_required  # Requires login to access this route
def home():
    return render_template("home.html", user=current_user)

# Route for the tables page
@views.route('/tables', methods=['GET', 'POST'])
def tables():
    return render_template("tables.html", user=current_user)

# MongoDB connection string
CONNECTION_STRING = "mongodb+srv://blessingsmlundira:vjOUpGcniJ1QuRMo@cluster0.71vdfjx.mongodb.net/test?retryWrites=true&w=majority"

# Connect to MongoDB
client = MongoClient(CONNECTION_STRING)
db = client.get_database('hospital_facilities')
collection = db.get_collection('facilities')

# Route for creating a new facility
@views.route('/create_facility', methods=['GET', 'POST'])
@login_required  # Requires login to access this route
def create_facility():
    data = request.form
    facility_name = data.get('facility_name')
    district_id = data.get('district_id')
    owner_id = data.get('owner_id')

    # Generate facility code
    district_code = get_district_code(district_id)
    facility_code = generate_facility_code(district_code)

    # Check if facility already exists in MHFR
    if facility_exists_in_MHFR(facility_name):
        flash('Facility already exists in MHFR', category='error')
        return jsonify({'error': 'Facility already exists in MHFR'})

    # Save facility to MongoDB
    facility_data = {
        'facility_name': facility_name,
        'district_id': district_id,
        'owner_id': owner_id,
        'facility_code': facility_code
    }
    collection.insert_one(facility_data)
    flash('Facility created succefully!', category='success')
    return jsonify({'success': 'Facility created successfully'})

# Function to generate a random facility code
def generate_facility_code(district_code):
    random_number = ''.join(random.choices(string.digits, k=6))
    return district_code + random_number

# Function to get district code from MHFR
def get_district_code(district_id):
    # Make request to MHFR API to get district code
    # Assume the MHFR API returns district code based on district_id
    # Replace the URL with the actual MHFR API endpoint
    mhfr_district_api_url = f"https://zipatala.health.gov.mw/api/districts/{district_id}"
    response = requests.get(mhfr_district_api_url)
    district_data = response.json()
    district_code = district_data.get('district_code', '')
    return district_code

# Function to check if facility exists in MHFR
def facility_exists_in_MHFR(facility_name):
    mhfr_facilities_api_url = "https://zipatala.health.gov.mw/api/facilities"
    response = requests.get(mhfr_facilities_api_url)
    facilities_data = response.json()
    for facility in facilities_data:
        if facility.get('facility_name') == facility_name:
            return True
    return False

# Route for archiving a facility
@views.route('/archive_facility/<facility_id>', methods=['POST'])
def archive_facility(facility_id):
    try:
        collection.update_one({'_id': ObjectId(facility_id)}, {'$set': {'archived': True}})
        return jsonify({'success': 'Facility archived successfully'})
    except Exception as e:
        return jsonify({'error': str(e)})

# Route for searching facilities
@views.route('/search_facilities', methods=['POST'])
def search_facilities():
    query = request.form.get('query')
    results = list(collection.find({'$text': {'$search': query}}))
    return jsonify(results)

# Route for filtering facilities
@views.route('/filter_facilities', methods=['POST'])
def filter_facilities():
    filter_criteria = request.form.get('filter_criteria')
    results = list(collection.find(filter_criteria))
    return jsonify(results)
